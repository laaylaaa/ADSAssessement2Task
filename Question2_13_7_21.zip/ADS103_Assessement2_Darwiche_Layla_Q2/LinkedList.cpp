#include "LinkedList.h"
#include <ctime>
#include <time.h>




void LinkedList::insertAtBeginnng(int value, clock_t end){

	clock_t start = clock();
	// points to where we built the new node
	Node* newNode = new Node(value); 

	// makes new node point to current head 
	newNode->next = head; 

	// update who is front of the list
	head = newNode; 

	end = clock(); 
}

void LinkedList::insertAtEnd(int value, clock_t end){

	clock_t start = clock();
	// if list is empty, use insert at front logic 
	if (head == NULL) {
		
		insertAtBeginnng(value, end);
		return;
	}

	Node* newNode = new Node(value);

	Node* iterator = head; // creates iterator and move to final thing in list
	while (iterator->next != NULL) {

		iterator = iterator->next; 
	}

	iterator->next = newNode; // pointing to the last position - attach newNode
	end = clock();

}

void LinkedList::deleteFromBeginning(clock_t end){

	clock_t start = clock();

	// delete nothing cause there is nothing... duh
	if (head == NULL) 
		return; 
	

	Node* iterator = head; 

	// move head up to the next position 
	head = head->next; 
	// delete old head. bye bye. 
	delete iterator; 
	end = clock();

}


void LinkedList::deleteFromEnd(clock_t end){

	clock_t start = clock();

	if (head == NULL) 
		return; 
	
	// get pointers to point to last node
	Node* iterator = head; 
	Node* previous = head; 

	while (iterator->next != NULL) {

		previous = iterator; // set it to whatever iterator on previous
		iterator = iterator->next; // set iterator to next node after iterator
	}

	// makes back point to nothing
	previous->next = NULL; 
	// delete last node 
	delete iterator; 
	end = clock();

}

void LinkedList::displayList(){

	Node* iterator = head;

	while (iterator != NULL) {

		// print out the name for each node 
		cout << iterator->data << endl; // -> dereference pointer and access public thing 
		iterator = iterator->next;
	}

}
