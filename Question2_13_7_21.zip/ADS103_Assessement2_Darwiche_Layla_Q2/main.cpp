// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <string>
#include <ctime>
#include "LinkedList.h"

// -------------- QUESTION 2 --------------

using namespace std;

void main() {

	// fstream classes for the input and output 
	fstream Q2InputFile; 
	fstream Q2OutputFile; 

	// two variables of linked list type 
	LinkedList linkedList1; 
	LinkedList linkedList2; 

	// how many elements I want to generate 
	int numberOfElements = 10; // 1369 
	int randNum;
	clock_t start, endOfLinkedList1{}, endOfLinkedList2{}; 
	// END OF LINK LIST GOES FOR ALL OF THE CLOCKs, HAVE TO HAVE ONE FOR EACH FUNCTION..

	srand(static_cast<unsigned int>(time(0))); // for random numbers

	// -----------------------------------------

	// insert at beginning for loop 
	cout << "INSERT AT BEGINNING" << endl;
	for (int i = 0; i < numberOfElements; i++) {
		//start = clock();
		randNum = (rand() % 100) + 1;
		linkedList1.insertAtBeginnng(randNum, endOfLinkedList1);

		//cout << "RandNum: " << randNum << endl; 
		//endOfLinkedList1 = clock();  
	}
	linkedList1.displayList(); 

	// -----------------------------------------

	// INSERTING AT THE END
	cout << "INSERT AT END" << endl;
	for (int i = 0; i < numberOfElements; i++) {
		//start = clock();
		randNum = (rand() % 100) + 1;
		linkedList2.insertAtEnd(randNum, endOfLinkedList1);

		//cout << "RandNum: " << randNum << endl; 
		//endOfLinkedList2 = clock();
	}
	linkedList2.displayList();

	// -----------------------------------------

	cout << "DELETE FROM BEGINNING" << endl;

	linkedList1.deleteFromBeginning(endOfLinkedList1);

	cout << "TIME!!!" << endl; 
	cout << endOfLinkedList1 << endl;

	//linkedList1.displayList();

	// -----------------------------------------

	cout << "DELETE FROM END" << endl;

	linkedList2.deleteFromEnd(endOfLinkedList2);

	cout << "TIME!!!" << endl;
	cout << endOfLinkedList2 << endl;

	//linkedList2.displayList();



	// creating input and output files
	Q2InputFile.open("input-a1q2.txt", ios::out); 
	Q2OutputFile.open("output-a1q2.txt", ios::out);

	if (Q2InputFile.is_open()) { // prints to input file number of elements for linked list

		Q2InputFile << "Generate and insert " << numberOfElements << " elements into the linked list!";
		Q2InputFile.close(); 
	}

}