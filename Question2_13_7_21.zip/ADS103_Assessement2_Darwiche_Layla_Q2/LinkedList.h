#pragma once
#include <iostream>
#include <string>
#include <time.h>
#include "Node.h"

using namespace std;

class LinkedList{

	public: 

		// points to the front of the linked list 
		Node* head = NULL; 

		void insertAtBeginnng(int value, clock_t end); 
		void insertAtEnd(int value, clock_t end);
		void deleteFromBeginning(clock_t end);
		void deleteFromEnd(clock_t end);
		void displayList(); 

};

