// Layla Darwiche 
// ADS103 
// Assignment 2
#pragma once
#include <iostream>
#include "Node.h"

using namespace std;

class LinkedList{

	public: 

		// points to the front of the linked list 
		Node* head = NULL; 

		void insertAtBeginnng(int value); 
		void insertAtEnd(int value);
		void deleteFromBeginning();
		void deleteFromEnd();
};

