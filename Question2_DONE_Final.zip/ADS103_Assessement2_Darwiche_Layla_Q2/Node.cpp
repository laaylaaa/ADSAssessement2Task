// Layla Darwiche 
// ADS103 
// Assignment 2
#include "Node.h"

Node::Node() { 
	
	next = NULL; 
}

Node::Node(int number) {

	next = NULL; 

	this->number = number;
	// number in node.h is passed thorugh this overload constructor
}
