// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <chrono>
#include "LinkedList.h"

using namespace std;

// -------------- QUESTION 2 --------------

void main() {

	// fstream classes for the input and output 
	fstream Q2InputFile; 
	fstream Q2OutputFile; 

	// two variables of linked list type 
	LinkedList linkedList1; 
	LinkedList linkedList2; 

	int randNum; // random number holder 
	int firstline; // input from first line 

	srand(static_cast<unsigned int>(time(0))); // for random numbers

	// creating input and output files
	Q2InputFile.open("input-a1q2.txt"); 
	Q2OutputFile.open("output-a1q2.txt", ios::out);

	if (Q2InputFile.is_open()) { // checks if the file is open

		Q2InputFile >> firstline; 
		cout << firstline << endl; 

		if (Q2OutputFile.is_open()) { // prints to output file all the times for each function to run 

			// -----INSERT AT BEGINNING--------
			std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now(); // start timer 
			for (int i = 0; i < firstline; i++) { // for loop to go through the amount of numbers specified in numberOfElements

				randNum = (rand() % 100) + 1; // getting a random number
				linkedList1.insertAtBeginnng(randNum); // calling function for this process(insert at beginning)
			}
			std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now(); // end timer

			// -----INSERTING AT THE END--------
			std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now();
			for (int i = 0; i < firstline; i++) {

				randNum = (rand() % 100) + 1;
				linkedList2.insertAtEnd(randNum);
			}
			std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now();

			// -----DELETE FROM BEGINNING--------
			std::chrono::steady_clock::time_point begin3 = std::chrono::steady_clock::now();
			for (int i = 0; i < firstline; i++) 
				linkedList1.deleteFromBeginning();
			std::chrono::steady_clock::time_point end3 = std::chrono::steady_clock::now();

			// -----DELETE FROM END--------
			std::chrono::steady_clock::time_point begin4 = std::chrono::steady_clock::now();
			for (int i = 0; i < firstline; i++) 
				linkedList2.deleteFromEnd();
			std::chrono::steady_clock::time_point end4 = std::chrono::steady_clock::now();

			// outputting the times it took for each function 
			Q2OutputFile << "Insert at beginning took: Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end1 - begin1).count() << "[ms]" << std::endl;
			Q2OutputFile << "Insert at end took: Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end2 - begin2).count() << "[ms]" << std::endl;
			Q2OutputFile << "Delete at beginning took: Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end3 - begin3).count() << "[ms]" << std::endl;
			Q2OutputFile << "Delete at end took: Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end4 - begin4).count() << "[ms]" << std::endl;

		}
	}

	// if there is no file, display error in console 
	if (!Q2InputFile.is_open()) {

		cout << "Error";
	}

	Q2InputFile.close();
	Q2OutputFile.close();
}