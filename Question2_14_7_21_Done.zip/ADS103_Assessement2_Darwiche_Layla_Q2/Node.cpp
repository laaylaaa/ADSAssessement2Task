#include "Node.h"

Node::Node() { 
	
	next = NULL; 

}

Node::Node(int data) {

	next = NULL; 

	this->data = data; 

}
