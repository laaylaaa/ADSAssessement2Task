#include "LinkedList.h"

void LinkedList::insertAtBeginnng(int value){


	// points to where we built the new node
	Node* newNode = new Node(value); 

	// makes new node point to current head 
	newNode->next = head; 

	// update who is front of the list
	head = newNode; 
}

void LinkedList::insertAtEnd(int value){

	// if list is empty, use insert at front logic 
	if (head == NULL) {
		
		insertAtBeginnng(value);
		return;
	}

	Node* newNode = new Node(value);

	Node* iterator = head; // creates iterator and move to final thing in list
	while (iterator->next != NULL) {

		iterator = iterator->next; 
	}

	iterator->next = newNode; // pointing to the last position - attach newNode
}

void LinkedList::deleteFromBeginning(){

	// delete nothing cause there is nothing... duh
	if (head == NULL) 
		return; 
	
	Node* iterator = head; 

	// move head up to the next position 
	head = head->next; 
	// delete old head. bye bye. 
	delete iterator; 
}


void LinkedList::deleteFromEnd(){
	
	if (head == NULL) 
		return; 
	
	// get pointers to point to last node
	Node* iterator = head; 
	Node* previous = head; 

	while (iterator->next != NULL) {

		previous = iterator; // set it to whatever iterator on previous
		iterator = iterator->next; // set iterator to next node after iterator
	}

	// makes back point to nothing
	previous->next = NULL; 
	// delete last node 
	delete iterator; 
}
