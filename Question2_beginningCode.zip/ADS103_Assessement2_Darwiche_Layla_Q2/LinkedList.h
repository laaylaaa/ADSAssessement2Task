#pragma once
#include <iostream>
#include <string>
#include "Node.h"

using namespace std;

class LinkedList{

	public: 

		// points to the front of the linked list 
		Node* head = NULL; 

		void insertAtBeginnng(int value); 
		void deleteFromBeginning(); 
		void insertAtEnd(int value); 
		void deleteFromEnd(); 

};

