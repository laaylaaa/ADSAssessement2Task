// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <ctime>
#include "LinkedList.h"

// -------------- QUESTION 2 --------------

using namespace std;

void main() {

	fstream Q2InputFile; 
	fstream Q2OutputFile; 

	LinkedList linkedList1; 
	LinkedList linkdList2; 

	Q2InputFile.open("input-a1q2.txt", ios::out); 
	Q2OutputFile.open("output-a1q2.txt", ios::out);



}