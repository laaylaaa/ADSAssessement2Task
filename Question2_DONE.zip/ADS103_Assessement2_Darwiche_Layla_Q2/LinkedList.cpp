// Layla Darwiche 
// ADS103 
// Assignment 2
#include "LinkedList.h"

void LinkedList::insertAtBeginnng(int value){

	// points to the newNode created 
	Node* newNode = new Node(value); 

	// newNode now points to the head -> 
	newNode->next = head; 

	// changes the head to the newNode created
	head = newNode; 
}

void LinkedList::insertAtEnd(int value){

	if (head == NULL) { // check to make sure list isnt empty 
		
		insertAtBeginnng(value); // if empty go to insertAtBeginning logic
		return; 
	}

	Node* newNode = new Node(value);

	Node* iterator = head; // iterator goes through the list till the last node 
	while (iterator->next != NULL) { // while the next iteration is not Null

		iterator = iterator->next; // keep going along list 
	}

	iterator->next = newNode; // once at the last node, insert newNode
}

void LinkedList::deleteFromBeginning(){

	// delete nothing cause there is nothing to delete... duh
	if (head == NULL) 
		return; 
	
	Node* iterator = head; // point iterator to head

	// move head up to the next position so we dont lose the new head
	head = head->next; 
	// delete old head. bye bye :)
	delete iterator; 
}


void LinkedList::deleteFromEnd(){
	
	if (head == NULL) 
		return; 
	
	// get pointers to point to last node
	Node* iterator = head; 
	Node* previous = head; 

	while (iterator->next != NULL) {

		previous = iterator; // set it to whatever iterator on previous
		iterator = iterator->next; // set iterator to next node after iterator
	}

	// makes the new back point to nothing
	previous->next = NULL; 
	// delete last node. rip 
	delete iterator; 
}
