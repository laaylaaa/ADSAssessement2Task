// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <ctime>
#include "LinkedList.h"

using namespace std;

// -------------- QUESTION 2 --------------

void main() {

	// fstream classes for the input and output 
	fstream Q2InputFile; 
	fstream Q2OutputFile; 

	// two variables of linked list type 
	LinkedList linkedList1; 
	LinkedList linkedList2; 

	// how many elements I want to generate 
	int numberOfElements = 1369; // I picked my own number, i dont know if you wanted the sample one or not but can be changed. 
	int randNum;

	// HAVE TO HAVE ONE FOR END OF EACH FUNCTION...
	clock_t startInsertB, startInsertE, startDeleteB, startDeleteE; 
	clock_t endInsertB, endInsertE, endDeleteB, endDeleteE;  

	srand(static_cast<unsigned int>(time(0))); // for random numbers

	// creating input and output files
	Q2InputFile.open("input-a1q2.txt", ios::out); 
	Q2OutputFile.open("output-a1q2.txt", ios::out);

	// -----INSERT AT BEGINNING--------
	startInsertB = clock(); // Starting timer 
	for (int i = 0; i < numberOfElements; i++) { // for loop to go through the amount of numbers specified in numberOfElements

		randNum = (rand() % 100) + 1; // getting a random number
		linkedList1.insertAtBeginnng(randNum); // calling function for this process(insert at beginning)
	}
	endInsertB = clock(); // Ending timer


	// -----INSERTING AT THE END--------
	startInsertE = clock();
	for (int i = 0; i < numberOfElements; i++) {

		randNum = (rand() % 100) + 1;
		linkedList2.insertAtEnd(randNum);
	}
	endInsertE = clock();

	// -----DELETE FROM BEGINNING--------
	startDeleteB = clock();
	for (int i = 0; i < numberOfElements; i++) {

		linkedList1.deleteFromBeginning();
	}
	endDeleteB = clock();


	// -----DELETE FROM END--------
	startDeleteE = clock();
	for (int i = 0; i < numberOfElements; i++) {

		linkedList2.deleteFromEnd();
	}
	endDeleteE = clock();

	if (Q2InputFile.is_open()) { // prints to input file number of elements for linked list

		Q2InputFile << "Generate and insert " << numberOfElements << " elements into the linked list!";
		Q2InputFile.close(); 
	}

	if (Q2OutputFile.is_open()) { // prints to output file all the times for each function to run 

		Q2OutputFile << "Time Taken for insert at beginning: 0.00" << endInsertB << " milliseconds" << endl;
		Q2OutputFile << "Time Taken for insert at end: 0.00" << endInsertE << " milliseconds" << endl;
		Q2OutputFile << "Time Taken for delete from beginning: 0.00" << endDeleteB << " milliseconds" << endl;
		Q2OutputFile << "Time Taken for delete from end: 0.00" << endDeleteE << " milliseconds" << endl;
		Q2OutputFile.close(); 
	}
}