// Layla Darwiche 
// ADS103 
// Assignment 2
#pragma once
#include <iostream>

using namespace std;

class Node
{
	public: 

		// int data element 
		int number; 

		// pointer to next node
		Node* next; 

		Node(); 
		Node(int number); // overload 

};

