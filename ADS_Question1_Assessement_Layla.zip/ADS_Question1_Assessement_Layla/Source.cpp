// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <ctime>

// -------------- QUESTION 1 --------------

using namespace std;
clock_t startQuick, endQuick; // timer for quick sort functions 

// https://slaystudy.com/c-vector-quicksort/
// To figure out quick sort used this websites code!
int implePartition(vector<int>& array, int start, int end, int order);
void applyQuickSort(vector<int>& array, int start, int end, int order);

void main() {

	// fstream is like a class, allows to print to txt file
	fstream Q1InputFile;
	fstream Q1OutputFile;

	// setting lines and creating array 
	string firstLineInp = "0";
	string secondLineInp = "1";
	string arrayInp = "20 45 71 91 1 5 40 31 9 6";
	vector<int> arr; 
	string thirdLineInp;
	string errorMessage = "Error! Not a 0 or 1!";
	int numberOfNumbersArr; 
	string errorMessageStat = "false";

	// -------------- INPUT --------------
	//creating text file for input 
	//Q1InputFile.open("input-a1q1.txt", ios::out);

	if (Q1InputFile.is_open()) {

		//if (firstLineInp != "0" && firstLineInp != "1" || secondLineInp != "0" && secondLineInp != "1") { // error checking 

		//	Q1InputFile << errorMessage;
		//	errorMessageStat = "true";
		//	exit(1);
		//}
		//else if (firstLineInp == "0" || firstLineInp == "1" || secondLineInp == "0" || secondLineInp == "1") {

		//	Q1InputFile << firstLineInp << endl; // printing int to txt file 
		//	Q1InputFile << secondLineInp << endl;
		//}

		//Q1InputFile << thirdLineInp << endl;

		Q1InputFile >> numberOfNumbersArr; 

		// outputting array 
		for (int i = 0; i < numberOfNumbersArr; i++) { 
			int temp; 
			Q1InputFile >> temp;   
			arr.push_back(temp);  
		}

		for (int i = 0; i < arr.size(); i++) {
			Q1InputFile << arr[i] << " ";
		}

		Q1InputFile.close();

		//getline(Q1InputFile, thirdLineInp);
		//numberOfNumbersArr = stoi(thirdLineInp); 
		//int* arr = new int[numberOfNumbersArr]; 
		//cout << numberOfNumbersArr; 

	}

	// -------------- OUTPUT --------------
	// creating txt file for output 
	Q1OutputFile.open("output-a1q1.txt", ios::out);

	if (Q1OutputFile.is_open()) {

		int firstLineOut;
		int secondLineOut;
		int thirdLineOut;
		string arrayOut;
		vector<int> array;

		clock_t start, end;
		int quickSortTime;

		// opens input file for READING! 
		Q1InputFile.open("input-a1q1.txt", ios::in);
		if (Q1InputFile.is_open()) {


			getline(Q1InputFile, firstLineInp); // gets line from the input file
			firstLineOut = stoi(firstLineInp); // changes string to int - stoi

			getline(Q1InputFile, secondLineInp);
			secondLineOut = stoi(secondLineInp);

			getline(Q1InputFile, thirdLineInp);
			thirdLineOut = stoi(thirdLineInp);

			getline(Q1InputFile, errorMessageStat);

			//if (errorMessageStat == "true") { // TRIED TO MAKE AN ERROR MESSAGE POP UP IF NOT 1 or 0 

			//	Q1OutputFile << "Error! Not a 0 or 1!" << endl;
			//	exit(1);
			//}

			getline(Q1InputFile, arrayInp);

			// https://www.delftstack.com/howto/cpp/string-to-int-array-in-cpp/
			// used the first code on this website to CHANGE THE STRING TO INT ARRAY 
			// changed around a bit to work with my code but same concept
			stringstream arr(arrayInp); // makes a stringstream class

			while (getline(arr, arrayOut, ' ')) {
				array.push_back(stoi(arrayOut));
			}

			if (firstLineOut == 0) { // ascending order - smallest to largest 

				if (secondLineOut == 0) { // bubble sort

					bool sorted = false;

					start = clock();
					while (!sorted) {

						//assume it is sorted until proven otherwise(if we have to swap)
						sorted = true;

						for (int i = 0; i < array.size() - 1; i++) {

							// compare current array value against the next one up 
							if (array[i] > array[i + 1]) {

								// if bigger, time to swap 
								swap(array[i], array[i + 1]);
								// assume this iteration is unsorted still
								sorted = false;

							}
						}
					}
					end = clock();

					Q1OutputFile << "Time it took(milliseconds): 0.00" << end << endl;
					Q1OutputFile << "BUBBLE SORT" << endl;
					for (int i = 0; i < array.size(); i++) {

						Q1OutputFile << array[i] << " ";
					}


				}
				else if (secondLineOut == 1) { // quick sort

					applyQuickSort(array, 0, array.size() - 1, firstLineOut);

					Q1OutputFile << "Time it took(milliseconds): 0.00" << endQuick << endl;
					Q1OutputFile << "QUICK SORT" << endl;
					for (int i = 0; i < array.size(); i++) {

						Q1OutputFile << array[i] << " ";
					}

				}
			}
			else if (firstLineOut == 1) { // descending order - largest to smallest 

				if (secondLineOut == 0) { // bubble sort
					bool sorted = false;

					start = clock();
					while (!sorted) {

						sorted = true;

						for (int i = 0; i < array.size() - 1; i++) {

							// opposite < symbol for descending order
							if (array[i] < array[i + 1]) {

								swap(array[i], array[i + 1]);
								sorted = false;

							}
						}
					}
					end = clock();

					Q1OutputFile << "Time it took(milliseconds): 0.00" << end << endl;
					Q1OutputFile << "BUBBLE SORT" << endl;
					for (int i = 0; i < array.size(); i++) {

						Q1OutputFile << array[i] << " ";
					}
				}
				else if (secondLineOut == 1) { // quick sort

					applyQuickSort(array, 0, array.size() - 1, firstLineOut);

					Q1OutputFile << "Time it took(milliseconds): 0.00" << endQuick << endl;
					Q1OutputFile << "QUICK SORT" << endl;
					for (int i = 0; i < array.size(); i++) {

						Q1OutputFile << array[i] << " ";
					}
				}
			}
		}

		Q1InputFile.close();
		Q1OutputFile.close();
	}
}

int implePartition(vector<int>& array, int start, int end, int order) {

	startQuick = clock(); // timer for quick sort start 
	int pivot = end; // last element is taken as the pivot 
	int j = start;
	if (order == 0) { // ascending order
		for (int i = start; i < end; i++) {
			if (array[i] < array[pivot]) {

				swap(array[i], array[j]);
				j++;
			}
		}
	}
	else if (order == 1) { // descedning order
		for (int i = start; i < end; i++) {
			if (array[i] > array[pivot]) {

				swap(array[i], array[j]);
				j++;
			}
		}
	}
	swap(array[j], array[pivot]);

	return j;
}

void applyQuickSort(vector<int>& array, int start, int end, int order) {

	if (start < end) {

		int p = implePartition(array, start, end, order);
		applyQuickSort(array, start, p - 1, order);
		applyQuickSort(array, p + 1, end, order);
	}

	endQuick = clock(); // timer for quick sort end 
}


//
//if (firstLineInp != "0" && firstLineInp != "1" || secondLineInp != "0" && secondLineInp != "1") { // error checking 
//
//	Q1InputFile << errorMessage;
//	errorMessageStat = "true";
//	exit(1);
//}
//else if (firstLineInp == "0" || firstLineInp == "1" || secondLineInp == "0" || secondLineInp == "1") {
//
//	Q1InputFile << firstLineInp << endl; // printing int to txt file 
//	Q1InputFile << secondLineInp << endl;
//}
//
//Q1InputFile << thirdLineInp << endl;
//
//// outputting array 
//for (int i = 0; i < 10; i++) {
//
//	Q1InputFile << arr1[i] << " ";
//}
//
//Q1InputFile.close();