// Layla Darwiche 
// ADS103 
// Assignment 2
#include <iostream>
#include <fstream>
#include <string>
#include <chrono>
#include <vector>

// -------------- QUESTION 1 --------------

using namespace std;

// https://slaystudy.com/c-vector-quicksort/
// To figure out quick sort used this websites code!
int implePartition(vector<int>& array, int start, int end, int order);
void applyQuickSort(vector<int>& array, int start, int end, int order);

void main() {

	// fstream is like a class, allows to print to txt file
	ifstream Q1InputFile;
	fstream Q1OutputFile;

	// VARIRABLES 
	int firstLineInp;
	int secondLineInp;
	vector<int> arr; 
	int numberOfNumbersArr; 
	clock_t start, end; 

	// -------------- INPUT --------------

	Q1InputFile.open("input-a1q1.txt");

	if (Q1InputFile.is_open()) { // check if input files open 

		cout << "------DATA FROM INPUT FILE!!------" << endl; 

		// collecting data from first three lines
		Q1InputFile >> firstLineInp; 
		cout << firstLineInp << endl; 

		Q1InputFile >> secondLineInp;
		cout << secondLineInp << endl; 

		Q1InputFile >> numberOfNumbersArr; 
		cout << numberOfNumbersArr << endl; 

		// inputting array 
		for (int i = 0; i < numberOfNumbersArr; i++) { 
			int temp; 
			Q1InputFile >> temp;   
			arr.push_back(temp);  
		}

		for (int i = 0; i < arr.size(); i++) {
			cout << arr[i] << " ";
		}
		cout << endl; 

		// -------------- OUTPUT --------------

		Q1OutputFile.open("output-a1q1.txt", ios::out);

		if (Q1OutputFile.is_open()) {
			if (firstLineInp == 0) { // ascending order - smallest to largest 

				if (secondLineInp == 0) { // bubble sort

					bool sorted = false;

					std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now(); // start timer 
					while (!sorted) {

						//assume it is sorted until proven otherwise(if we have to swap)
						sorted = true;

						for (int i = 0; i < arr.size() - 1; i++) {

							// compare current array value against the next one up 
							if (arr[i] > arr[i + 1]) {

								// if bigger, time to swap 
								swap(arr[i], arr[i + 1]);
								// assume this iteration is unsorted still
								sorted = false;
							}
						}
					}
					std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now(); // end timer
					Q1OutputFile << "Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end1 - begin1).count() << "[ms]" << std::endl; // outputting the time

					Q1OutputFile << "BUBBLE SORT" << endl;
					for (int i = 0; i < arr.size(); i++) // outputting sorted array 
						Q1OutputFile << arr[i] << " ";
				}
				else if (secondLineInp == 1) { // quick sort
					std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now(); 
					applyQuickSort(arr, 0, arr.size() - 1, firstLineInp); // calling the quick sort 
					std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now(); 

					Q1OutputFile << "Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end2 - begin2).count() << "[ms]" << std::endl; 
					Q1OutputFile << "QUICK SORT" << endl;

					for (int i = 0; i < arr.size(); i++)
						Q1OutputFile << arr[i] << " ";
				}

				if (secondLineInp != 0 && secondLineInp != 1) { // error checking - making sure they put in correct number for second line 

					Q1OutputFile << "Error! Need to input a 1 or 0 in the second line! Duhhhhh!!"; 
					exit(1); 
				}
			}
			else if (firstLineInp == 1) { // descending order - largest to smallest 

				if (secondLineInp == 0) { // bubble sort
					bool sorted = false;

					std::chrono::steady_clock::time_point begin1 = std::chrono::steady_clock::now();
					while (!sorted) {

						sorted = true;

						for (int i = 0; i < arr.size() - 1; i++) {

							// opposite < symbol for descending order
							if (arr[i] < arr[i + 1]) {

								swap(arr[i], arr[i + 1]);
								sorted = false;
							}
						}
					}
					std::chrono::steady_clock::time_point end1 = std::chrono::steady_clock::now();

					Q1OutputFile << "Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end1 - begin1).count() << "[ms]" << std::endl;
					Q1OutputFile << "BUBBLE SORT" << endl;

					for (int i = 0; i < arr.size(); i++)
						Q1OutputFile << arr[i] << " ";
				}
				else if (secondLineInp == 1) { // quick sort
					std::chrono::steady_clock::time_point begin2 = std::chrono::steady_clock::now();
					applyQuickSort(arr, 0, arr.size() - 1, firstLineInp);
					std::chrono::steady_clock::time_point end2 = std::chrono::steady_clock::now();

					Q1OutputFile << "Milliseconds = " << std::chrono::duration_cast<std::chrono::milliseconds>(end2 - begin2).count() << "[ms]" << std::endl;
					Q1OutputFile << "QUICK SORT" << endl;

					for (int i = 0; i < arr.size(); i++)
						Q1OutputFile << arr[i] << " ";
				}

				if (secondLineInp != 0 && secondLineInp != 1) { // error checking 

					Q1OutputFile << "Error! Need to input a 1 or 0 in the second line! Duhhhhh!!" << endl;
					exit(1);
				}
			}

			if (firstLineInp != 0 && firstLineInp != 1) { // error checking - making sure they put in right number for first line 
				Q1OutputFile << "Error! Need to input a 1 or 0 in the first line! Duhhhhh!!" << endl;
				exit(1);
			}
		}
	}

	// if there is no file, display error in console 
	if (!Q1InputFile.is_open()){ 

		cout << "Error"; 
	}
	
	// close files 
	Q1InputFile.close();
	Q1OutputFile.close(); 
}

// --------- QUICK SORT ---------
int implePartition(vector<int>& array, int start, int end, int order) {

	int pivot = end; // last element is taken as the pivot 
	int j = start;
	if (order == 0) { // ascending order
		for (int i = start; i < end; i++) {
			if (array[i] < array[pivot]) {

				swap(array[i], array[j]);
				j++;
			}
		}
	}
	else if (order == 1) { // descedning order
		for (int i = start; i < end; i++) {
			if (array[i] > array[pivot]) {

				swap(array[i], array[j]);
				j++;
			}
		}
	}
	swap(array[j], array[pivot]);

	return j;
}

void applyQuickSort(vector<int>& array, int start, int end, int order) {

	if (start < end) {

		int p = implePartition(array, start, end, order);
		applyQuickSort(array, start, p - 1, order);
		applyQuickSort(array, p + 1, end, order);
	}
}